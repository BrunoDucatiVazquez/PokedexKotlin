package br.com.fabricadesinapse.pokedex_android.domain

data class PokemonType(
    val name: String
)
